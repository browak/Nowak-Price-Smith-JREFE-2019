## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----realEstateDictionaries----------------------------------------------
library(nowakPriceSmithJREFE)
require(SparseM)
require(glmnet)
data(listings)
str(listings)

## ----message=FALSE, warning=FALSE----------------------------------------
text0 <- head(listings$remarks , n=3)
text0

## ----message=FALSE, warning=FALSE----------------------------------------
text1 <- cleanText(text0)
text1

## ----message=FALSE, warning=FALSE----------------------------------------
text2 <- cleanText(text0 , removeStopWords = FALSE)
text2

## ----message=FALSE, warning=FALSE----------------------------------------
M1 <- tokenMatrixMaker(text1)
head(M1)
colnames(M1)

## ----message=FALSE, warning=FALSE----------------------------------------
M1 <- tokenMatrixMaker(text1 , GRAM=2 , KTOKEN=10)
head(M1)
colnames(M1)

## ----message=FALSE, warning=FALSE----------------------------------------
X <- as.matrix(cbind(listings$sqft,listings$sqft**2))
text0 <- listings$remarks
text1 <- cleanText(text0)
M <- tokenMatrixMaker(text1 , GRAM=1 , KTOKEN=500)
y <- log(listings$price)
fit <- lassoPostLasso(X,M,y)

## ------------------------------------------------------------------------
fit$predictionInformation

## ------------------------------------------------------------------------
head(fit$cvDictionary)
head(fit$hetDictionary)

## ------------------------------------------------------------------------
head(fit$fittedValues)

## ------------------------------------------------------------------------
listings$sqft2 <- listings$sqft**2
listings$logprice <- log(listings$price)
fitWrapper <- realEstateDictionary(XVARS=c("sqft","sqft2"),
                        TEXTVAR="remarks",
                        YVAR="logprice",
                        DATA=listings)
head(fitWrapper$hetDictionary)

