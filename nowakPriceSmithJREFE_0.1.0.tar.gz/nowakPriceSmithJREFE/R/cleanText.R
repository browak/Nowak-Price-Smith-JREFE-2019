cleanText <- function(TEXT ,
                      lower=NULL ,
                      removeNumbers=NULL ,
                      removePunctuation=NULL ,
                      removeStopWords=NULL,
                      removeSingleLetters=NULL,
                      verbose=TRUE)
{
### is TEXT a character string?
if(class(TEXT)!="character") stop("TEXT is not a character class")
### setup
if(missing(lower)) lower <- TRUE
if(missing(removeNumbers)) removeNumbers <- TRUE
if(missing(removePunctuation)) removePunctuation <- TRUE
if(missing(removeStopWords)) removeStopWords <- TRUE
if(missing(removeSingleLetters)) removeSingleLetters <- TRUE
if(missing(verbose)) verbose <- FALSE
### step 1
if(lower & verbose) print("convert to lower case")
if(lower) TEXT <- tolower(TEXT)
### numbers
if(removeNumbers & verbose) print("remove numbers")
if(removeNumbers) TEXT <- gsub("[0-9]"," ",TEXT)
### punctuation
if(removePunctuation & verbose) print("remove punctuation")
if(removePunctuation) TEXT <- gsub("[[:punct:]]+","",TEXT)
### stop words
if(removeStopWords & verbose) print("remove stop words")
if(removeStopWords) TEXT <- tm::removeWords(TEXT,tm::stopwords(kind="en"))
### single letters
if(removeSingleLetters & verbose) print("remove single letters")
if(removeSingleLetters) TEXT <- tm::removeWords(TEXT,letters)
### remove white space
if(verbose) print("remove white space")
TEXT <- gsub("[[:blank:]]+"," ",TEXT)
TEXT <- trimws(TEXT)
### output
return(TEXT)
}
