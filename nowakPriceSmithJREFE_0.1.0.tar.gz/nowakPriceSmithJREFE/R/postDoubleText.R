postDoubleText <- function(CONTROLMAT,
                           TEXT,
                           DEPVAR,
                           VAROFINTEREST,
                           GRAM=NULL,
                           KTOKEN=NULL,
                           REDUNDANTTOKENS=NULL)
{
if(is.null(GRAM)) GRAM <- 1
if(is.null(KTOKEN)) KTOKEN <- 500
TOKENMAT <- tokenMatrixMaker(TEXT, GRAM=GRAM , KTOKEN=KTOKEN)
if(!is.null(REDUNDANTTOKENS)) TOKENMAT <- TOKENMAT[,!(colnames(TOKENMAT)%in%REDUNDANTTOKENS)]
XY <- cbind(CONTROLMAT,TOKENMAT,VAROFINTEREST)
colnames(XY)[ncol(XY)] <- "variableOfInterest"
### lasso y
LASSOY <- clusterLasso(XXX=XY,YYY=DEPVAR,UNPENALIZEDVARS="variableOfInterest")
SY <- intersect(LASSOY$S , colnames(TOKENMAT))
### lasso d
XD <- cbind(CONTROLMAT,TOKENMAT)
LASSOD <- clusterLasso(XXX=XD,YYY=VAROFINTEREST)
SD <- intersect(LASSOD$S , colnames(TOKENMAT))
S2 <- union(SY,SD)
S2 <- intersect(S2,colnames(TOKENMAT))
### post lasso
X2 <- cbind(CONTROLMAT,TOKENMAT[,colnames(TOKENMAT)%in%S2],VAROFINTEREST)
X2 <- as.matrix(X2)
FIT <- lm(DEPVAR ~ X2)
return(FIT)
}
