postLasso <- function(XXX,YYY)
{
#require(slam)
#require(SparseM)
#require(Matrix)
if(class(XXX)[1]!="dgCMatrix") XXX <- as(XXX, "sparseMatrix")
  	COLMAX <- slam::colapply_simple_triplet_matrix( slam::as.simple_triplet_matrix(XXX) , max )
	COLMIN <- slam::colapply_simple_triplet_matrix( slam::as.simple_triplet_matrix(XXX) , min )
  	if(min(COLMAX-COLMIN)!=0) XXX <- cbind(XXX,1)
	#setClass("matrix.csc",representation(ra="numeric",ja="integer",ia="integer", dimension="integer"))
	XCSC <- new("matrix.csc", ra = XXX@x,
              ja = XXX@i + 1L,
              ia = XXX@p + 1L,
              dimension = XXX@Dim)
	XCSR <- as.matrix.csr(XCSC)
	slmFit <- slm.fit(XCSR,YYY,tmpmax=1000*nrow(XXX))
return(slmFit)
}
